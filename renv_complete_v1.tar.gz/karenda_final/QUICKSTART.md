# renv - クイックスタートガイド

自転車ショップ向けの来店予約・管理システム「renv」を素早くセットアップして、動作確認するためのガイドです。

## 必要な環境

- Python 3.8以上
- pip（Pythonパッケージマネージャー）
- SQLite3（Djangoのデフォルトデータベース）

## セットアップ手順

### 1. プロジェクトの解凍

```bash
tar -xzf renv_final.tar.gz
cd karenda_final
```

### 2. 仮想環境の作成（推奨）

```bash
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# または
venv\Scripts\activate  # Windows
```

### 3. 依存パッケージのインストール

```bash
pip install -r requirements.txt
# または
pip install django pillow
```

### 4. データベースの初期化

```bash
python manage.py migrate
```

### 5. 初期データの作成

```bash
python manage.py shell < seed_data.py
```

このコマンドで以下が作成されます：
- 管理者ユーザー（username: `admin`, password: `admin123`）
- デモユーザー（username: `demo`, password: `demo123`）
- サンプルメニュー（5種類）
- 予約可能な時間枠（4種類）
- 定休日設定（毎週月曜日）

### 6. 開発サーバーの起動

```bash
python manage.py runserver
```

サーバーが起動すると、以下のメッセージが表示されます：

```
Starting development server at http://127.0.0.1:8000/
```

## アクセスURL

| 画面 | URL | ユーザー |
|------|-----|---------|
| ユーザー向け予約画面 | http://localhost:8000/ | demo |
| 管理者ダッシュボード | http://localhost:8000/dashboard/ | admin |
| Django Admin | http://localhost:8000/admin/ | admin |

## ログイン情報

### 管理者アカウント
- **ユーザー名**: `admin`
- **パスワード**: `admin123`

### デモユーザーアカウント
- **ユーザー名**: `demo`
- **パスワード**: `demo123`

## 動作確認チェックリスト

### ユーザー側の機能確認

- [ ] トップページにアクセスできる
- [ ] 新規登録ができる
- [ ] ログインできる
- [ ] 予約フォームが表示される
- [ ] メニューを選択できる
- [ ] 日付と時間枠を選択できる
- [ ] 自転車情報を入力できる
- [ ] 写真をアップロードできる
- [ ] 予約が完了する
- [ ] マイページで予約を確認できる
- [ ] 予約をキャンセルできる

### 管理者側の機能確認

- [ ] ダッシュボードにアクセスできる
- [ ] 本日の予約が表示される
- [ ] 予約一覧が表示される
- [ ] 予約を検索・フィルタできる
- [ ] 予約詳細が表示される
- [ ] 自転車情報が表示される
- [ ] 写真が表示される
- [ ] 作業履歴を編集できる
- [ ] 見積金額を入力できる
- [ ] 完了写真をアップロードできる
- [ ] メニュー一覧が表示される
- [ ] メニューを追加・編集できる
- [ ] 休日一覧が表示される
- [ ] 休日を追加・編集できる

## よくある問題と解決方法

### ポート8000が既に使用されている

```bash
python manage.py runserver 8001
```

別のポート（例：8001）で起動してください。

### データベースエラーが発生する

```bash
rm db.sqlite3
python manage.py migrate
python manage.py shell < seed_data.py
```

データベースをリセットしてください。

### 画像がアップロードできない

1. `media/` ディレクトリが存在することを確認
2. ディレクトリに書き込み権限があることを確認
3. Pillow がインストールされていることを確認：`pip install pillow`

### メール送信がコンソールに出力される

開発環境では、メール送信がコンソールに出力されるように設定されています。これは正常な動作です。

本番環境でメール送信を有効化するには、`settings.py` を編集してください。

## プロジェクト構造

```
karenda_final/
├── reservation_project/          # Djangoプロジェクト設定
│   ├── settings.py              # プロジェクト設定
│   ├── urls.py                  # URL設定
│   └── wsgi.py
├── reservations/                # ユーザー向け予約アプリ
│   ├── models.py                # データモデル
│   ├── views.py                 # ビュー
│   ├── forms.py                 # フォーム
│   ├── urls.py                  # URL設定
│   ├── email_utils.py           # メール送信ユーティリティ
│   ├── templates/               # テンプレート
│   ├── static/                  # CSS/JavaScript
│   └── migrations/              # マイグレーション
├── dashboard/                   # 管理者ダッシュボードアプリ
│   ├── views.py                 # ビュー
│   ├── urls.py                  # URL設定
│   ├── templates/               # テンプレート
│   └── ...
├── media/                       # アップロード画像保存先
├── manage.py                    # Django管理コマンド
├── seed_data.py                 # 初期データ作成スクリプト
└── requirements.txt             # 依存パッケージ一覧
```

## 次のステップ

### メール機能を有効化する

`settings.py` のメール設定を編集して、本番環境でのメール送信を有効化できます。

### リマインダーメール自動送信を設定する

`django-crontab` を使用して、毎日決まった時間にリマインダーメールを送信できます。

### デプロイ準備

- `DEBUG = False` に設定
- `SECRET_KEY` を環境変数から取得
- `ALLOWED_HOSTS` を適切に設定
- HTTPS を有効化
- 本番用データベース（PostgreSQL等）に変更

## トラブルシューティング

### 詳細なエラーメッセージが表示されない

`settings.py` で `DEBUG = True` に設定されていることを確認してください。

### マイグレーションが失敗する

```bash
python manage.py showmigrations
python manage.py migrate --fake-initial
```

### スタティックファイル（CSS等）が読み込まれない

```bash
python manage.py collectstatic
```

## サポート

問題が発生した場合は、以下をご確認ください：

1. Python のバージョン確認：`python --version`
2. Django のバージョン確認：`python -m django --version`
3. 依存パッケージの確認：`pip list`
4. ログの確認：コンソール出力を確認

## ライセンス

このプロジェクトはMITライセンスの下で公開されています。

---

**Happy Coding! 🚲**
